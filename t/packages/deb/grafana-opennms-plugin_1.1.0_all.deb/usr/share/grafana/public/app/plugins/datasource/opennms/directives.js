/*! grafana - v2.5.0 - 2015-10-29
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular"],function(a){"use strict";var b=a.module("grafana.directives");b.directive("metricQueryEditorOpennms",function(){return{controller:"OpenNMSQueryCtrl",templateUrl:"app/plugins/datasource/opennms/partials/query.editor.html"}}),b.directive("metricQueryOptionsOpennms",function(){return{templateUrl:"app/plugins/datasource/opennms/partials/query.options.html"}})});